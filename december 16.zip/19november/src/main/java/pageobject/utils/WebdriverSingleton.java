package pageobject.utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebdriverSingleton {

    private static WebDriver webDriver;

    private WebdriverSingleton() {
    }

public static WebDriver getInstance(){
        if (webDriver == null){
            WebDriverManager.chromedriver().setup();
            webDriver = new ChromeDriver();
        }

        return webDriver;
}

}
